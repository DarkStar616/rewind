import { defineConfig } from 'tsup';

/**
 * Build configuration for @takk/agenticstash.
 *
 * Ten library entry points (dual ESM + CJS, each with its own .d.ts) plus the Node-only CLI
 * (ESM with shebang). Every library bundle is platform-neutral and pulls no Node built-in (the seal
 * uses the Web Crypto API, not node:crypto), so the whole record/replay surface (record, replay,
 * storage, fork, diff, interceptors, the MCP bridge, the integrity seal, and edge) is importable in
 * browsers, edge runtimes, and embedded targets. The CLI is the only Node-targeted artifact; it
 * reads and writes recording files through `node:fs` and `node:process`.
 */
export default defineConfig([
  {
    entry: {
      index: 'src/index.ts',
      'record/index': 'src/record/index.ts',
      'replay/index': 'src/replay/index.ts',
      'storage/index': 'src/storage/index.ts',
      'fork/index': 'src/fork/index.ts',
      'diff/index': 'src/diff/index.ts',
      'interceptors/index': 'src/interceptors/index.ts',
      'mcp/index': 'src/mcp/index.ts',
      'seal/index': 'src/seal/index.ts',
      'edge/index': 'src/edge/index.ts',
    },
    format: ['esm', 'cjs'],
    dts: true,
    sourcemap: true,
    clean: true,
    treeshake: true,
    splitting: false,
    minify: false,
    target: 'es2022',
    platform: 'neutral',
    removeNodeProtocol: false,
    external: [/^node:/],
  },
  {
    entry: {
      'cli/index': 'src/cli/index.ts',
    },
    format: ['esm'],
    dts: false,
    sourcemap: true,
    clean: false,
    treeshake: true,
    splitting: false,
    minify: false,
    target: 'es2022',
    platform: 'node',
    banner: {
      js: '#!/usr/bin/env node',
    },
  },
]);
