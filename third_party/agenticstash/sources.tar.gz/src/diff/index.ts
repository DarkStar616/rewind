/**
 * The diff engine: compare two recordings to find precisely where they diverge.
 *
 * Events are aligned by their (channel, key, ordinal) identity, not by raw sequence, so an inserted
 * or removed call does not misalign everything after it. The result separates events that were
 * added, removed, or changed, and reports the earliest point of divergence, which answers the core
 * debugging question after a code change: "the run that broke first differs here."
 *
 * @packageDocumentation
 */

import { BlobStore } from '../storage/index.js';
import type { Outcome, RecordedEvent, Recording } from '../types.js';

/** An event present in only one of the two recordings. */
export interface EventOnly {
  readonly channel: string;
  readonly key: string;
  readonly ordinal: number;
  readonly seq: number;
  readonly outcome: Outcome;
  readonly value: unknown;
}

/** An event present in both recordings whose value or outcome changed. */
export interface EventChange {
  readonly channel: string;
  readonly key: string;
  readonly ordinal: number;
  readonly seqA: number;
  readonly seqB: number;
  readonly outcomeA: Outcome;
  readonly outcomeB: Outcome;
  readonly before: unknown;
  readonly after: unknown;
}

/** The result of diffing two recordings. */
export interface DiffResult {
  /** Whether the two recordings are event-for-event identical. */
  readonly identical: boolean;
  /** Events present only in the second recording. */
  readonly added: readonly EventOnly[];
  /** Events present only in the first recording. */
  readonly removed: readonly EventOnly[];
  /** Events present in both whose recorded value or outcome differs. */
  readonly changed: readonly EventChange[];
  /** The earliest diverging event by identity, when the recordings differ. */
  readonly firstDivergence?: {
    readonly channel: string;
    readonly key: string;
    readonly ordinal: number;
  };
}

const identity = (event: RecordedEvent): string => `${event.channel} ${event.key} ${event.ordinal}`;

/** Compares two recordings and reports added, removed, and changed events. */
export function diffRecordings(a: Recording, b: Recording): DiffResult {
  const blobsA = BlobStore.fromRecord(a.blobs);
  const blobsB = BlobStore.fromRecord(b.blobs);
  const mapA = new Map<string, RecordedEvent>();
  const mapB = new Map<string, RecordedEvent>();
  for (const event of a.events) {
    mapA.set(identity(event), event);
  }
  for (const event of b.events) {
    mapB.set(identity(event), event);
  }
  const resolveValue = (store: BlobStore, ref: string): unknown =>
    store.has(ref) ? store.get(ref) : null;

  const added: EventOnly[] = [];
  const removed: EventOnly[] = [];
  const changed: EventChange[] = [];

  for (const [id, event] of mapA) {
    const other = mapB.get(id);
    if (!other) {
      removed.push({
        channel: event.channel,
        key: event.key,
        ordinal: event.ordinal,
        seq: event.seq,
        outcome: event.outcome,
        value: resolveValue(blobsA, event.ref),
      });
    } else if (other.ref !== event.ref || other.outcome !== event.outcome) {
      changed.push({
        channel: event.channel,
        key: event.key,
        ordinal: event.ordinal,
        seqA: event.seq,
        seqB: other.seq,
        outcomeA: event.outcome,
        outcomeB: other.outcome,
        before: resolveValue(blobsA, event.ref),
        after: resolveValue(blobsB, other.ref),
      });
    }
  }
  for (const [id, event] of mapB) {
    if (!mapA.has(id)) {
      added.push({
        channel: event.channel,
        key: event.key,
        ordinal: event.ordinal,
        seq: event.seq,
        outcome: event.outcome,
        value: resolveValue(blobsB, event.ref),
      });
    }
  }

  added.sort((x, y) => x.seq - y.seq);
  removed.sort((x, y) => x.seq - y.seq);
  changed.sort((x, y) => x.seqA - y.seqA);

  const candidates: Array<{ seq: number; channel: string; key: string; ordinal: number }> = [];
  for (const c of changed) {
    candidates.push({ seq: c.seqA, channel: c.channel, key: c.key, ordinal: c.ordinal });
  }
  for (const r of removed) {
    candidates.push({ seq: r.seq, channel: r.channel, key: r.key, ordinal: r.ordinal });
  }
  for (const a_ of added) {
    candidates.push({ seq: a_.seq, channel: a_.channel, key: a_.key, ordinal: a_.ordinal });
  }
  candidates.sort((x, y) => x.seq - y.seq);

  const identical = added.length === 0 && removed.length === 0 && changed.length === 0;
  const first = candidates[0];
  if (identical || first === undefined) {
    return { identical, added, removed, changed };
  }
  return {
    identical,
    added,
    removed,
    changed,
    firstDivergence: { channel: first.channel, key: first.key, ordinal: first.ordinal },
  };
}
