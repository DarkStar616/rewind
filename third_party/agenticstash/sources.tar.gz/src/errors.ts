/**
 * The single error type raised by Agentic Stash.
 *
 * Every refusal carries a stable, machine-readable {@link AgenticStashError.code}. Branch on the
 * code, never on the message; messages are for humans and may change between releases.
 *
 * @packageDocumentation
 */

/** The stable set of error codes Agentic Stash can raise. */
export type AgenticStashErrorCode =
  | 'ERR_DIVERGENCE'
  | 'ERR_RECORDING_EXHAUSTED'
  | 'ERR_INVALID_RECORDING'
  | 'ERR_INVALID_INPUT'
  | 'ERR_NOT_FOUND';

/** A structured, code-tagged error. The only error type the library throws on purpose. */
export class AgenticStashError extends Error {
  /** Stable machine-readable error code, for example `'ERR_DIVERGENCE'`. */
  readonly code: AgenticStashErrorCode;
  /** Optional structured details, safe to log; never contains secrets. */
  readonly details?: Readonly<Record<string, unknown>>;

  constructor(
    message: string,
    code: AgenticStashErrorCode,
    details?: Readonly<Record<string, unknown>>,
  ) {
    super(message);
    this.name = 'AgenticStashError';
    this.code = code;
    if (details !== undefined) {
      this.details = details;
    }
    Object.setPrototypeOf(this, new.target.prototype);
  }

  /** Builds an `'ERR_DIVERGENCE'` error, when a replayed call does not match the recording. */
  static divergence(
    message: string,
    details?: Readonly<Record<string, unknown>>,
  ): AgenticStashError {
    return new AgenticStashError(message, 'ERR_DIVERGENCE', details);
  }

  /** Builds an `'ERR_RECORDING_EXHAUSTED'` error, when replay asks for an event past the recording. */
  static exhausted(
    message: string,
    details?: Readonly<Record<string, unknown>>,
  ): AgenticStashError {
    return new AgenticStashError(message, 'ERR_RECORDING_EXHAUSTED', details);
  }

  /** Builds an `'ERR_INVALID_RECORDING'` error, when a recording fails validation on load. */
  static invalidRecording(
    message: string,
    details?: Readonly<Record<string, unknown>>,
  ): AgenticStashError {
    return new AgenticStashError(message, 'ERR_INVALID_RECORDING', details);
  }

  /** Builds an `'ERR_INVALID_INPUT'` error, for a malformed argument or option. */
  static invalidInput(
    message: string,
    details?: Readonly<Record<string, unknown>>,
  ): AgenticStashError {
    return new AgenticStashError(message, 'ERR_INVALID_INPUT', details);
  }

  /** Builds an `'ERR_NOT_FOUND'` error, for a missing blob, event, or record. */
  static notFound(message: string, details?: Readonly<Record<string, unknown>>): AgenticStashError {
    return new AgenticStashError(message, 'ERR_NOT_FOUND', details);
  }
}

/** Type guard: is this value an {@link AgenticStashError}? */
export function isAgenticStashError(value: unknown): value is AgenticStashError {
  return value instanceof AgenticStashError;
}
