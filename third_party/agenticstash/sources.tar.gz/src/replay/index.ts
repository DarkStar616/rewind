/**
 * The replayer: serves a {@link Recording} back so surrounding code re-executes deterministically.
 *
 * For each intercepted call, the replayer returns the next recorded value for that (channel, key)
 * pair, re-throwing a recorded error exactly where the original run threw. When a call supplies an
 * `input`, its hash is checked against the recorded input hash. With the default `onDivergence:
 * 'throw'` a mismatch raises `ERR_DIVERGENCE` on the spot; with `onDivergence: 'collect'` every
 * divergence is recorded and replay continues, so a single pass yields a full {@link DivergenceReport}
 * of exactly where the code under replay departed from the recording. Asking past the end of the
 * recording raises `ERR_RECORDING_EXHAUSTED` unless the call opts into a live tail (used by forks).
 *
 * @packageDocumentation
 */

import { AgenticStashError } from '../errors.js';
import { hashValue } from '../hash.js';
import { BlobStore } from '../storage/index.js';
import type {
  Divergence,
  DivergenceReport,
  InterceptOptions,
  RecordedEvent,
  Recording,
} from '../types.js';
import { reviveError } from '../wire.js';

/** Options for {@link createReplayer}. */
export interface ReplayerOptions {
  /**
   * When true (the default), a supplied input whose hash does not match the recorded input raises
   * `ERR_DIVERGENCE`. When false, the recorded value is returned without an input check.
   */
  readonly strict?: boolean;
  /**
   * What to do on a divergence: `'throw'` (default) raises on the first one; `'collect'` records it
   * and keeps replaying so {@link Replayer.report} returns every divergence from one pass.
   */
  readonly onDivergence?: 'throw' | 'collect';
}

/** Serves recorded events deterministically in place of live non-determinism. */
export interface Replayer {
  /** Replays the next recorded value for a call, running `produce` only for a live tail. */
  replay<T>(channel: string, key: string, produce?: () => T, options?: InterceptOptions): T;
  /** Async form of {@link Replayer.replay}. */
  replayAsync<T>(
    channel: string,
    key: string,
    produce?: () => Promise<T>,
    options?: InterceptOptions,
  ): Promise<T>;
  /** Number of recorded events consumed so far. */
  consumed(): number;
  /** Recorded events not yet consumed, in order. */
  remaining(): RecordedEvent[];
  /** Divergences collected so far (only populated when `onDivergence` is `'collect'`). */
  divergences(): Divergence[];
  /** A full divergence report: collected divergences plus any never-consumed events as misses. */
  report(): DivergenceReport;
  /** The recording being replayed. */
  recording(): Recording;
}

interface NextEvent {
  readonly event: RecordedEvent;
  readonly consume: () => void;
}

/** Creates a {@link Replayer} over a recording. */
export function createReplayer(recording: Recording, options: ReplayerOptions = {}): Replayer {
  const strict = options.strict ?? true;
  const collect = options.onDivergence === 'collect';
  const blobs = BlobStore.fromRecord(recording.blobs);
  const byComposite = new Map<string, RecordedEvent[]>();
  for (const event of recording.events) {
    const composite = `${event.channel} ${event.key}`;
    const list = byComposite.get(composite);
    if (list) {
      list.push(event);
    } else {
      byComposite.set(composite, [event]);
    }
  }
  const cursors = new Map<string, number>();
  const consumedSeqs = new Set<number>();
  const collected: Divergence[] = [];

  const next = (channel: string, key: string): NextEvent | undefined => {
    const composite = `${channel} ${key}`;
    const list = byComposite.get(composite);
    const cursor = cursors.get(composite) ?? 0;
    if (!list || cursor >= list.length) {
      return undefined;
    }
    const event = list[cursor];
    if (event === undefined) {
      return undefined;
    }
    return {
      event,
      consume: () => {
        cursors.set(composite, cursor + 1);
        consumedSeqs.add(event.seq);
      },
    };
  };

  const inputDivergence = (
    event: RecordedEvent,
    options_?: InterceptOptions,
  ): Divergence | undefined => {
    if (!strict || !options_ || options_.input === undefined || event.inputRef === undefined) {
      return undefined;
    }
    const actual = hashValue(options_.input);
    if (actual === event.inputRef) {
      return undefined;
    }
    return {
      kind: 'input-mismatch',
      channel: event.channel,
      key: event.key,
      ordinal: event.ordinal,
      seq: event.seq,
      expected: event.inputRef,
      actual,
      detail: `input for '${event.channel}/${event.key}' (event ${event.seq}) does not match the recording`,
    };
  };

  const resolve = (event: RecordedEvent): unknown => {
    const payload = blobs.get(event.ref);
    if (event.outcome === 'throw') {
      throw reviveError(payload);
    }
    return payload;
  };

  const onExtraCall = (
    channel: string,
    key: string,
    produce: (() => unknown) | undefined,
  ): { live: true; value: unknown } => {
    collected.push({
      kind: 'extra-call',
      channel,
      key,
      detail: `replay made a call to '${channel}/${key}' with no recorded event remaining`,
    });
    if (produce === undefined) {
      throw AgenticStashError.exhausted(
        `replay reached the end of recorded events for '${channel}/${key}' and no live producer was provided`,
        { channel, key },
      );
    }
    return { live: true, value: produce() };
  };

  const replay = <T>(
    channel: string,
    key: string,
    produce?: () => T,
    options_?: InterceptOptions,
  ): T => {
    const found = next(channel, key);
    if (!found) {
      if (options_?.allowLiveTail) {
        return (produce === undefined ? undefined : produce()) as T;
      }
      if (collect) {
        return onExtraCall(channel, key, produce).value as T;
      }
      throw AgenticStashError.exhausted(
        `replay reached the end of recorded events for '${channel}/${key}'`,
        { channel, key },
      );
    }
    const divergence = inputDivergence(found.event, options_);
    if (divergence) {
      if (collect) {
        collected.push(divergence);
      } else {
        throw AgenticStashError.divergence(divergence.detail, {
          channel: divergence.channel,
          key: divergence.key,
          seq: divergence.seq,
          expected: divergence.expected,
          actual: divergence.actual,
        });
      }
    }
    found.consume();
    return resolve(found.event) as T;
  };

  const replayAsync = async <T>(
    channel: string,
    key: string,
    produce?: () => Promise<T>,
    options_?: InterceptOptions,
  ): Promise<T> => {
    const found = next(channel, key);
    if (!found) {
      if (options_?.allowLiveTail) {
        return (produce === undefined ? undefined : await produce()) as T;
      }
      if (collect) {
        return (await onExtraCall(channel, key, produce).value) as T;
      }
      throw AgenticStashError.exhausted(
        `replay reached the end of recorded events for '${channel}/${key}'`,
        { channel, key },
      );
    }
    const divergence = inputDivergence(found.event, options_);
    if (divergence) {
      if (collect) {
        collected.push(divergence);
      } else {
        throw AgenticStashError.divergence(divergence.detail, {
          channel: divergence.channel,
          key: divergence.key,
          seq: divergence.seq,
          expected: divergence.expected,
          actual: divergence.actual,
        });
      }
    }
    found.consume();
    return resolve(found.event) as T;
  };

  const remaining = (): RecordedEvent[] =>
    recording.events.filter((event) => !consumedSeqs.has(event.seq));

  const report = (): DivergenceReport => {
    const misses: Divergence[] = remaining().map((event) => ({
      kind: 'missing-call',
      channel: event.channel,
      key: event.key,
      ordinal: event.ordinal,
      seq: event.seq,
      detail: `recorded event ${event.seq} for '${event.channel}/${event.key}' was never replayed`,
    }));
    const all = [...collected, ...misses].sort((a, b) => (a.seq ?? Infinity) - (b.seq ?? Infinity));
    const base: DivergenceReport = {
      matched: all.length === 0,
      divergences: all,
      consumed: consumedSeqs.size,
    };
    const first = all[0];
    return first === undefined ? base : { ...base, firstDivergence: first };
  };

  return {
    replay,
    replayAsync,
    consumed: () => consumedSeqs.size,
    remaining,
    divergences: () => [...collected],
    report,
    recording: () => recording,
  };
}
