/**
 * The shared type surface of Agentic Stash.
 *
 * A {@link RecordedEvent} is the atom: one captured source of non-determinism (a model output, a
 * tool or MCP response, a clock read, a random draw, an environment read). A {@link Recording} is
 * the ordered tape of those events plus a content-addressed blob table that deduplicates repeated
 * payloads. Recording captures the tape; replay serves it back so the surrounding code re-executes
 * deterministically. Determinism here is by substitution: Agentic Stash does not make a model
 * deterministic, it replays the exact values the original run observed.
 *
 * @packageDocumentation
 */

/**
 * A logical channel a non-deterministic value flows through, for example `'llm'`, `'tool'`,
 * `'mcp'`, `'clock'`, or `'random'`. Channels are free-form; pick stable names per source.
 */
export type Channel = string;

/** Whether a recorded call returned a value or threw. */
export type Outcome = 'return' | 'throw';

/** The mode a {@link Stash} operates in. */
export type StashMode = 'record' | 'replay';

/** One captured non-deterministic event. */
export interface RecordedEvent {
  /** Global monotonic sequence across the whole recording, zero-based. */
  readonly seq: number;
  /** The channel this event belongs to. */
  readonly channel: Channel;
  /** A caller-supplied stable key identifying the call site within the channel. */
  readonly key: string;
  /** Ordinal of this event within its (channel, key) pair, zero-based. */
  readonly ordinal: number;
  /** Whether the recorded call returned a value or threw. */
  readonly outcome: Outcome;
  /** Content-addressed reference into {@link Recording.blobs} for the returned value or thrown error. */
  readonly ref: string;
  /** Content-addressed reference for the call's input, present only when an input was supplied. */
  readonly inputRef?: string;
  /** Recorded wall-clock time of the call, epoch milliseconds. Informational, never used for replay. */
  readonly at?: number;
  /** Free-form label for human inspection. */
  readonly label?: string;
}

/** A complete recording of one agent run. */
export interface Recording {
  /** Envelope format version. */
  readonly version: 1;
  /** Stable identifier for this recording. */
  readonly id: string;
  /** Events in capture order. */
  readonly events: readonly RecordedEvent[];
  /** Content-addressed blob table: hash to JSON-serializable payload. */
  readonly blobs: Readonly<Record<string, unknown>>;
  /** Free-form metadata (created time, app name, and so on). Never used for replay. */
  readonly meta: Readonly<Record<string, unknown>>;
}

/** Options accepted when intercepting a call on a {@link Stash}. */
export interface InterceptOptions {
  /**
   * The call's input. When supplied, its content hash is recorded; on replay a mismatch against the
   * recorded input hash raises a divergence error, the signal that the code changed since recording.
   */
  readonly input?: unknown;
  /** Free-form label stored on the event for human inspection. */
  readonly label?: string;
  /**
   * When replaying past the end of the recorded events for this call (for example the live tail
   * after a fork), run the live producer instead of raising. Defaults to `false`.
   */
  readonly allowLiveTail?: boolean;
}

/** Context passed to a {@link RedactFn} for each value about to be stored. */
export interface RedactContext {
  /** The channel of the call whose payload is being stored. */
  readonly channel: Channel;
  /** The key of the call whose payload is being stored. */
  readonly key: string;
  /** Whether the payload is the call's return value (or error) or its input. */
  readonly kind: 'value' | 'input';
}

/**
 * Transforms a value before it is written to a recording, so secrets and PII never reach storage.
 *
 * Return a masked value to keep structure while hiding content, or the exported `DROP` sentinel to
 * store nothing but a redaction marker (a metadata-only event). Redaction is a record-time, one-way
 * transform: a redacted field replays as its redacted form, so redact only what replay does not need
 * to reproduce, or accept reduced replay fidelity on those fields.
 */
export type RedactFn = (value: unknown, context: RedactContext) => unknown;

/** Options for creating a {@link Stash}. */
export interface StashOptions {
  /** Stable id for the recording (record mode); defaults to a hash of the metadata. */
  readonly id?: string;
  /** Free-form metadata stored on the recording; never used for replay. */
  readonly meta?: Readonly<Record<string, unknown>>;
  /** Clock used to stamp each event's informational `at` (record mode); omit to leave it unset. */
  readonly now?: () => number;
  /** When present, the stash replays this recording instead of recording a new one. */
  readonly replay?: Recording;
  /** Replay strictness (replay mode); defaults to true. See the replay module. */
  readonly strict?: boolean;
  /**
   * What a replay does on a divergence (replay mode). `'throw'` (the default) raises on the first
   * divergence; `'collect'` records every divergence and keeps replaying, so one pass produces a
   * full {@link DivergenceReport} of where the code under replay departed from the recording.
   */
  readonly onDivergence?: 'throw' | 'collect';
  /**
   * Redacts each value and input before it is stored (record mode), so secrets and PII never reach
   * the recording. See {@link RedactFn}.
   */
  readonly redact?: RedactFn;
}

/**
 * The unified record-or-replay facade, the "git stash" of agent runs.
 *
 * Write the agent once against {@link Stash.intercept}. Created without a recording it records; given
 * a recording it replays the same calls deterministically, so one code path serves both modes.
 */
export interface Stash {
  /** Whether this stash is recording or replaying. */
  readonly mode: StashMode;
  /** Records (or replays) an async (or sync) producer for a (channel, key) call. */
  intercept<T>(
    channel: Channel,
    key: string,
    produce: () => Promise<T> | T,
    options?: InterceptOptions,
  ): Promise<T>;
  /** Synchronous form of {@link Stash.intercept}. */
  interceptSync<T>(channel: Channel, key: string, produce: () => T, options?: InterceptOptions): T;
  /** Records a value directly (record mode) or returns the recorded value (replay mode). */
  value<T>(channel: Channel, key: string, value: T, options?: InterceptOptions): T;
  /** The recording captured so far (record mode) or being replayed (replay mode). */
  recording(): Recording;
  /** The recording serialized to a portable JSON string. */
  save(): string;
  /** Number of recorded events consumed (replay mode); zero in record mode. */
  consumed(): number;
  /** Recorded events not yet consumed (replay mode); empty in record mode. */
  remaining(): RecordedEvent[];
  /** Divergences collected so far (replay mode with `onDivergence: 'collect'`); empty otherwise. */
  divergences(): Divergence[];
  /** A full divergence report of replay versus the recording (replay mode); empty in record mode. */
  report(): DivergenceReport;
}

/** The kind of a replay divergence. */
export type DivergenceKind = 'input-mismatch' | 'extra-call' | 'missing-call';

/** One way the code under replay departed from the recording. */
export interface Divergence {
  /** What kind of departure this is. */
  readonly kind: DivergenceKind;
  /** The channel of the diverging call. */
  readonly channel: Channel;
  /** The key of the diverging call. */
  readonly key: string;
  /** The (channel, key) ordinal involved, when known. */
  readonly ordinal?: number;
  /** The recorded global sequence involved, when known. */
  readonly seq?: number;
  /** The recorded input hash, for an input mismatch. */
  readonly expected?: string;
  /** The replayed input hash, for an input mismatch. */
  readonly actual?: string;
  /** A human-readable description. */
  readonly detail: string;
}

/** A full report of how a replay departed from its recording. */
export interface DivergenceReport {
  /** Whether the replay matched the recording with zero divergences. */
  readonly matched: boolean;
  /** Every divergence, ordered by recorded sequence then discovery order. */
  readonly divergences: readonly Divergence[];
  /** The earliest divergence, when any. */
  readonly firstDivergence?: Divergence;
  /** Count of recorded events consumed during the replay. */
  readonly consumed: number;
}

/** A tamper-evident integrity seal over a {@link Recording}. */
export interface RecordingSeal {
  /** Seal format version. */
  readonly version: 1;
  /** The digest algorithm; always `'SHA-256'` in this release. */
  readonly algorithm: 'SHA-256';
  /** The root digest of the SHA-256 hash chain over the recording, hex-encoded. */
  readonly root: string;
  /** Number of events folded into the chain. */
  readonly count: number;
}

/** The result of verifying a {@link Recording} against a {@link RecordingSeal}. */
export interface VerifyResult {
  /** Whether the recomputed root matches the seal. */
  readonly valid: boolean;
  /** The root recorded in the seal. */
  readonly expectedRoot: string;
  /** The root recomputed from the recording now. */
  readonly actualRoot: string;
  /** Why verification failed, when it did. */
  readonly reason?: string;
}

/** Summary statistics for a {@link Recording}. */
export interface RecordingStats {
  /** Total number of events. */
  readonly events: number;
  /** Distinct channels and how many events each holds. */
  readonly channels: Readonly<Record<Channel, number>>;
  /** Number of distinct content-addressed blobs. */
  readonly blobs: number;
  /** Number of recorded throws. */
  readonly throws: number;
}
