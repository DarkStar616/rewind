/**
 * Internal wire helpers for persisting and reviving thrown errors inside a recording.
 *
 * A recorded throw stores a plain, JSON-serializable snapshot of the error so replay can re-throw an
 * equivalent error. {@link AgenticStashError} instances round-trip with their code and details; any
 * other error round-trips by name and message. This module is internal and not a public entry point.
 *
 * @packageDocumentation
 */

import { AgenticStashError } from './errors.js';

/** A JSON-serializable snapshot of a thrown error. */
export interface WireError {
  /** Marker so a revived blob is recognizable as an error snapshot. */
  readonly __error: true;
  /** The error's `name`. */
  readonly name: string;
  /** The error's `message`. */
  readonly message: string;
  /** The {@link AgenticStashError} code, present only for that error type. */
  readonly code?: string;
  /** The {@link AgenticStashError} details, present only when set. */
  readonly details?: Readonly<Record<string, unknown>>;
}

/** Snapshots a thrown value into a JSON-serializable {@link WireError}. */
export function serializeError(error: unknown): WireError {
  if (error instanceof AgenticStashError) {
    const wire: WireError = {
      __error: true,
      name: error.name,
      message: error.message,
      code: error.code,
    };
    return error.details === undefined ? wire : { ...wire, details: error.details };
  }
  if (error instanceof Error) {
    return { __error: true, name: error.name, message: error.message };
  }
  return { __error: true, name: 'Error', message: String(error) };
}

/** Rebuilds a throwable error from a recorded snapshot. */
export function reviveError(value: unknown): Error {
  const wire = value as Partial<WireError> | null;
  const message = wire && typeof wire.message === 'string' ? wire.message : 'recorded error';
  if (wire && typeof wire.code === 'string') {
    return new AgenticStashError(
      message,
      wire.code as AgenticStashError['code'],
      wire.details as Readonly<Record<string, unknown>> | undefined,
    );
  }
  const error = new Error(message);
  if (wire && typeof wire.name === 'string') {
    error.name = wire.name;
  }
  return error;
}
