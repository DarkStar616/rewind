/**
 * Agentic Stash: deterministic record and replay for Massive Intelligence (IM) agents and non-human
 * entities (NHEs).
 *
 * The rr of the agentic world, the git stash of agent runs. Agents are non-deterministic by design:
 * model outputs are sampled, tool and MCP responses depend on external state, the clock and
 * randomness drift. Agentic Stash captures every such source during a run and serves it back on
 * replay, so an irreproducible production failure becomes a step-through-debuggable one. Record once,
 * replay deterministically, fork a run to explore an alternate decision, and diff two runs to find
 * exactly where they diverged. Determinism is by substitution: the library replays the values the
 * original run observed, it does not make a model deterministic. Zero runtime dependencies.
 *
 * @packageDocumentation
 */

import { createRecorder } from './record/index.js';
import { createReplayer } from './replay/index.js';
import { decodeRecording, encodeRecording } from './storage/index.js';
import type { InterceptOptions, RecordedEvent, Recording, Stash, StashOptions } from './types.js';

export type { DiffResult, EventChange, EventOnly } from './diff/index.js';
export { diffRecordings } from './diff/index.js';
export * from './errors.js';
export type { ForkOptions } from './fork/index.js';
export { fork } from './fork/index.js';
export { hashString, hashValue, stableStringify } from './hash.js';
export type {
  DeterministicClock,
  SeededRandom,
} from './interceptors/index.js';
export {
  createDeterministicClock,
  createSeededRandom,
  wrap,
  wrapSync,
} from './interceptors/index.js';
export type { Recorder, RecorderOptions } from './record/index.js';
export { createRecorder, DROP } from './record/index.js';
export type { Replayer, ReplayerOptions } from './replay/index.js';
export { createReplayer } from './replay/index.js';
export { sealRecording, verifyRecording } from './seal/index.js';
export {
  BlobStore,
  decodeRecording,
  encodeRecording,
  recordingStats,
} from './storage/index.js';
export * from './types.js';

/**
 * Creates a {@link Stash}.
 *
 * Without a `replay` option it records; with one it replays that recording. The same intercepted
 * code runs in both modes, so you instrument an agent once and switch behavior by how you construct
 * the stash.
 */
export function createStash(options: StashOptions = {}): Stash {
  if (options.replay) {
    const recording = options.replay;
    const replayer = createReplayer(recording, {
      ...(options.strict === undefined ? {} : { strict: options.strict }),
      ...(options.onDivergence === undefined ? {} : { onDivergence: options.onDivergence }),
    });
    const intercept = <T>(
      channel: string,
      key: string,
      produce: () => Promise<T> | T,
      opts?: InterceptOptions,
    ): Promise<T> => replayer.replayAsync(channel, key, () => Promise.resolve(produce()), opts);
    return {
      mode: 'replay',
      intercept,
      interceptSync: (channel, key, produce, opts) => replayer.replay(channel, key, produce, opts),
      value: (channel, key, value, opts) => replayer.replay(channel, key, () => value, opts),
      recording: () => recording,
      save: () => encodeRecording(recording),
      consumed: () => replayer.consumed(),
      remaining: () => replayer.remaining(),
      divergences: () => replayer.divergences(),
      report: () => replayer.report(),
    };
  }

  const recorder = createRecorder({
    ...(options.id === undefined ? {} : { id: options.id }),
    ...(options.meta === undefined ? {} : { meta: options.meta }),
    ...(options.now === undefined ? {} : { now: options.now }),
    ...(options.redact === undefined ? {} : { redact: options.redact }),
  });
  const intercept = <T>(
    channel: string,
    key: string,
    produce: () => Promise<T> | T,
    opts?: InterceptOptions,
  ): Promise<T> => recorder.recordAsync(channel, key, () => Promise.resolve(produce()), opts);
  return {
    mode: 'record',
    intercept,
    interceptSync: (channel, key, produce, opts) => recorder.record(channel, key, produce, opts),
    value: (channel, key, value, opts) => recorder.value(channel, key, value, opts),
    recording: () => recorder.recording(),
    save: () => encodeRecording(recorder.recording()),
    consumed: () => 0,
    remaining: () => [],
    divergences: () => [],
    report: () => ({ matched: true, divergences: [], consumed: 0 }),
  };
}

/** Loads a recording from JSON and returns a replay-mode {@link Stash}. */
export function loadStash(
  json: string,
  options: { readonly strict?: boolean; readonly onDivergence?: 'throw' | 'collect' } = {},
): Stash {
  return createStash({
    replay: decodeRecording(json),
    ...(options.strict === undefined ? {} : { strict: options.strict }),
    ...(options.onDivergence === undefined ? {} : { onDivergence: options.onDivergence }),
  });
}

export type { InterceptOptions, RecordedEvent, Recording, Stash, StashOptions };
