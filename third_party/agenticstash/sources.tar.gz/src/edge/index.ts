/**
 * The edge entry point.
 *
 * The whole Agentic Stash engine is free of any Node built-in (the integrity seal uses Web Crypto,
 * not node:crypto), so this entry re-exports the entire core (record, replay, storage, fork, diff,
 * interceptors, the seal, the stash facade) plus the MCP bridge, unchanged, for Cloudflare Workers,
 * Vercel Edge, Deno, Bun, and the browser. The only Node-specific surface is the CLI, which is not
 * exported here.
 *
 * @packageDocumentation
 */

export * from '../index.js';
export type { McpClientLike, McpToolCall } from '../mcp/index.js';
export { interceptMcpClient, recordMcpTool } from '../mcp/index.js';
