/**
 * Tamper-evident integrity sealing for recordings.
 *
 * {@link sealRecording} folds the recording id and every event (with its referenced value and input
 * payloads) into a SHA-256 hash chain and returns the root digest; {@link verifyRecording} recomputes
 * the chain and reports whether the recording is byte-for-byte the one that was sealed. Any change to
 * an event, a recorded value, their order, or the id breaks the root, which is the integrity property
 * the EU AI Act Article 12 tamper-evident logging requirement asks of agent execution records.
 *
 * This is an integrity seal, not a digital signature: it proves a recording matches a trusted root,
 * not who produced it. Pair the root with your own signing or notarization for non-repudiation. The
 * digest uses the Web Crypto API (`crypto.subtle`), available in Node, Deno, Bun, edge runtimes, and
 * browsers, so the seal stays dependency-free and runs everywhere the engine does.
 *
 * @packageDocumentation
 */

import { AgenticStashError } from '../errors.js';
import { stableStringify } from '../hash.js';
import type { RecordedEvent, Recording, RecordingSeal, VerifyResult } from '../types.js';

const encoder = new TextEncoder();

/** Resolves the Web Crypto SubtleCrypto, throwing a clear error if the runtime lacks it. */
function subtle(): SubtleCrypto {
  const webcrypto = (globalThis as { crypto?: Crypto }).crypto;
  if (!webcrypto?.subtle) {
    throw AgenticStashError.invalidInput(
      'Web Crypto (crypto.subtle) is unavailable in this runtime; sealing requires SHA-256',
    );
  }
  return webcrypto.subtle;
}

/** Hashes UTF-8 text with SHA-256 and returns a lowercase hex digest. */
async function sha256Hex(text: string): Promise<string> {
  const digest = await subtle().digest('SHA-256', encoder.encode(text));
  const bytes = new Uint8Array(digest);
  let hex = '';
  for (const byte of bytes) {
    hex += byte.toString(16).padStart(2, '0');
  }
  return hex;
}

/** Canonical, order-stable serialization of one event together with its referenced payloads. */
function canonicalEvent(recording: Recording, event: RecordedEvent): string {
  const value = event.ref in recording.blobs ? recording.blobs[event.ref] : null;
  const input =
    event.inputRef !== undefined && event.inputRef in recording.blobs
      ? recording.blobs[event.inputRef]
      : null;
  return stableStringify({
    seq: event.seq,
    channel: event.channel,
    key: event.key,
    ordinal: event.ordinal,
    outcome: event.outcome,
    value,
    input,
  });
}

/** Computes the SHA-256 hash-chain root over a recording's id and events. */
async function chainRoot(recording: Recording): Promise<string> {
  let chain = await sha256Hex(`agenticstash:seal:1:${recording.id}`);
  for (const event of recording.events) {
    chain = await sha256Hex(`${chain}|${canonicalEvent(recording, event)}`);
  }
  return chain;
}

/** Seals a recording, returning a tamper-evident {@link RecordingSeal}. */
export async function sealRecording(recording: Recording): Promise<RecordingSeal> {
  const root = await chainRoot(recording);
  return { version: 1, algorithm: 'SHA-256', root, count: recording.events.length };
}

/** Verifies a recording against a previously computed {@link RecordingSeal}. */
export async function verifyRecording(
  recording: Recording,
  seal: RecordingSeal,
): Promise<VerifyResult> {
  const actualRoot = await chainRoot(recording);
  if (seal.count !== recording.events.length) {
    return {
      valid: false,
      expectedRoot: seal.root,
      actualRoot,
      reason: `event count changed: sealed ${seal.count}, found ${recording.events.length}`,
    };
  }
  if (actualRoot !== seal.root) {
    return {
      valid: false,
      expectedRoot: seal.root,
      actualRoot,
      reason: 'recomputed root does not match the seal; the recording was modified',
    };
  }
  return { valid: true, expectedRoot: seal.root, actualRoot };
}

export type { RecordingSeal, VerifyResult } from '../types.js';
