/**
 * The `agenticstash` executable.
 *
 * Wires the real process streams and the filesystem into the pure {@link runCli} command logic and
 * exits with its sysexits-style code. All testable behavior lives in commands.ts; this file is the
 * thin Node entry the bin field points at.
 *
 * @packageDocumentation
 */

import { readFileSync, writeFileSync } from 'node:fs';
import process from 'node:process';
import { runCli } from './commands.js';

runCli({
  argv: process.argv.slice(2),
  write: (text) => {
    process.stdout.write(text);
  },
  error: (text) => {
    process.stderr.write(text);
  },
  readFile: (path) => readFileSync(path, 'utf8'),
  writeFile: (path, text) => {
    writeFileSync(path, text, 'utf8');
  },
})
  .then((code) => {
    process.exit(code);
  })
  .catch((error: unknown) => {
    process.stderr.write(
      `agenticstash: ${error instanceof Error ? error.message : String(error)}\n`,
    );
    process.exit(70);
  });
