/**
 * The `agenticstash` command logic, decoupled from the process for in-process testing.
 *
 * Every side effect (argv, stdout, stderr, file reads and writes) arrives through {@link CliIO}, so
 * the suite drives the CLI without spawning a process. The bin wires the real streams. Exit codes
 * follow the sysexits convention: 0 success, 64 usage error, 65 bad input data, 66 input not
 * readable; `verify` additionally exits 1 when a recording fails its integrity seal.
 *
 * @packageDocumentation
 */

import { diffRecordings } from '../diff/index.js';
import { AgenticStashError } from '../errors.js';
import { fork } from '../fork/index.js';
import { sealRecording, verifyRecording } from '../seal/index.js';
import { decodeRecording, encodeRecording, recordingStats } from '../storage/index.js';
import type { Recording, RecordingSeal } from '../types.js';
import { flagNumber, flagString, parseArgs } from './args.js';

/** The package version, kept in sync with package.json at release time. */
const VERSION = '1.0.0';

/** Injected process surface so commands are pure and testable. */
export interface CliIO {
  /** The argv tail after the binary name. */
  readonly argv: readonly string[];
  /** Writes to standard output. */
  write(text: string): void;
  /** Writes to standard error. */
  error(text: string): void;
  /** Reads a file as UTF-8 text; may throw if the path is unreadable. */
  readFile(path: string): string;
  /** Writes a file as UTF-8 text; may throw if the path is unwritable. */
  writeFile(path: string, text: string): void;
}

const HELP = `agenticstash, deterministic record and replay for agents

Usage:
  agenticstash inspect <recording.json> [--json]
  agenticstash diff <a.json> <b.json> [--json]
  agenticstash fork <recording.json> --at <seq> [--out <file>] [--json]
  agenticstash seal <recording.json> [--out <seal.json>]
  agenticstash verify <recording.json> <seal.json>
  agenticstash version
  agenticstash help

A recording is the JSON tape produced by a recording stash (stash.save()).
inspect summarizes it, diff finds where two runs diverged, fork derives an
alternate branch from a decision point, seal writes a tamper-evident SHA-256
integrity seal, and verify checks a recording against its seal (exit 1 if it
was modified).
`;

/** Extracts a human-readable message from an unknown thrown value. */
function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

/** Loads and decodes a recording file, mapping failures to sysexits codes via thrown errors. */
function loadRecording(io: CliIO, path: string): Recording {
  return decodeRecording(io.readFile(path));
}

/** `inspect` command. */
function cmdInspect(
  io: CliIO,
  positionals: readonly string[],
  flags: Readonly<Record<string, string | boolean>>,
): number {
  const path = positionals[1];
  if (path === undefined) {
    io.error('usage: agenticstash inspect <recording.json> [--json]\n');
    return 64;
  }
  let recording: Recording;
  try {
    recording = loadRecording(io, path);
  } catch (error) {
    io.error(`agenticstash: ${messageOf(error)}\n`);
    return error instanceof AgenticStashError ? 65 : 66;
  }
  const stats = recordingStats(recording);
  if (flags.json === true) {
    io.write(`${JSON.stringify({ id: recording.id, ...stats }, null, 2)}\n`);
    return 0;
  }
  io.write(`recording: ${recording.id}\n`);
  io.write(`events:    ${stats.events}\n`);
  io.write(`blobs:     ${stats.blobs}\n`);
  io.write(`throws:    ${stats.throws}\n`);
  io.write('channels:\n');
  for (const [channel, count] of Object.entries(stats.channels)) {
    io.write(`  ${channel.padEnd(16)} ${count}\n`);
  }
  return 0;
}

/** `diff` command. */
function cmdDiff(
  io: CliIO,
  positionals: readonly string[],
  flags: Readonly<Record<string, string | boolean>>,
): number {
  const pathA = positionals[1];
  const pathB = positionals[2];
  if (pathA === undefined || pathB === undefined) {
    io.error('usage: agenticstash diff <a.json> <b.json> [--json]\n');
    return 64;
  }
  let a: Recording;
  let b: Recording;
  try {
    a = loadRecording(io, pathA);
    b = loadRecording(io, pathB);
  } catch (error) {
    io.error(`agenticstash: ${messageOf(error)}\n`);
    return error instanceof AgenticStashError ? 65 : 66;
  }
  const result = diffRecordings(a, b);
  if (flags.json === true) {
    io.write(`${JSON.stringify(result, null, 2)}\n`);
    return 0;
  }
  if (result.identical) {
    io.write('recordings are identical\n');
    return 0;
  }
  io.write(
    `added: ${result.added.length}  removed: ${result.removed.length}  changed: ${result.changed.length}\n`,
  );
  if (result.firstDivergence) {
    const d = result.firstDivergence;
    io.write(`first divergence: ${d.channel}/${d.key} #${d.ordinal}\n`);
  }
  for (const change of result.changed.slice(0, 10)) {
    io.write(`  changed ${change.channel}/${change.key} #${change.ordinal}\n`);
  }
  return 0;
}

/** `fork` command. */
function cmdFork(
  io: CliIO,
  positionals: readonly string[],
  flags: Readonly<Record<string, string | boolean>>,
): number {
  const path = positionals[1];
  if (path === undefined) {
    io.error('usage: agenticstash fork <recording.json> --at <seq> [--out <file>]\n');
    return 64;
  }
  const at = flagNumber(flags, 'at', Number.NaN);
  if (!Number.isInteger(at)) {
    io.error('agenticstash: fork requires --at <seq> (an integer event index)\n');
    return 64;
  }
  let recording: Recording;
  try {
    recording = loadRecording(io, path);
  } catch (error) {
    io.error(`agenticstash: ${messageOf(error)}\n`);
    return error instanceof AgenticStashError ? 65 : 66;
  }
  let forked: Recording;
  try {
    forked = fork(recording, { at });
  } catch (error) {
    io.error(`agenticstash: ${messageOf(error)}\n`);
    return 65;
  }
  const json = encodeRecording(forked);
  const out = flagString(flags, 'out', '');
  if (out !== '') {
    try {
      io.writeFile(out, `${json}\n`);
    } catch (error) {
      io.error(`agenticstash: ${messageOf(error)}\n`);
      return 66;
    }
    io.write(`forked ${recording.id} at ${at} -> ${forked.id} (${out})\n`);
    return 0;
  }
  io.write(`${json}\n`);
  return 0;
}

/** `seal` command. */
async function cmdSeal(
  io: CliIO,
  positionals: readonly string[],
  flags: Readonly<Record<string, string | boolean>>,
): Promise<number> {
  const path = positionals[1];
  if (path === undefined) {
    io.error('usage: agenticstash seal <recording.json> [--out <seal.json>]\n');
    return 64;
  }
  let recording: Recording;
  try {
    recording = loadRecording(io, path);
  } catch (error) {
    io.error(`agenticstash: ${messageOf(error)}\n`);
    return error instanceof AgenticStashError ? 65 : 66;
  }
  const seal = await sealRecording(recording);
  const json = JSON.stringify(seal, null, 2);
  const out = flagString(flags, 'out', '');
  if (out !== '') {
    try {
      io.writeFile(out, `${json}\n`);
    } catch (error) {
      io.error(`agenticstash: ${messageOf(error)}\n`);
      return 66;
    }
    io.write(`sealed ${recording.id}: ${seal.root} (${out})\n`);
    return 0;
  }
  io.write(`${json}\n`);
  return 0;
}

/** `verify` command. */
async function cmdVerify(io: CliIO, positionals: readonly string[]): Promise<number> {
  const recordingPath = positionals[1];
  const sealPath = positionals[2];
  if (recordingPath === undefined || sealPath === undefined) {
    io.error('usage: agenticstash verify <recording.json> <seal.json>\n');
    return 64;
  }
  let recording: Recording;
  let seal: RecordingSeal;
  try {
    recording = loadRecording(io, recordingPath);
    seal = JSON.parse(io.readFile(sealPath)) as RecordingSeal;
  } catch (error) {
    io.error(`agenticstash: ${messageOf(error)}\n`);
    return error instanceof AgenticStashError ? 65 : 66;
  }
  const result = await verifyRecording(recording, seal);
  if (result.valid) {
    io.write(`valid: ${recording.id} matches the seal (${result.actualRoot})\n`);
    return 0;
  }
  io.error(`INVALID: ${result.reason ?? 'recording does not match the seal'}\n`);
  io.error(`  expected ${result.expectedRoot}\n`);
  io.error(`  actual   ${result.actualRoot}\n`);
  return 1;
}

/** Runs the CLI against an injected IO surface and returns the process exit code. */
export async function runCli(io: CliIO): Promise<number> {
  const { positionals, flags } = parseArgs(io.argv);
  const command = positionals[0];

  switch (command) {
    case undefined:
    case 'help':
    case '--help':
      io.write(HELP);
      return 0;
    case 'version':
    case '--version':
      io.write(`${VERSION}\n`);
      return 0;
    case 'inspect':
      return cmdInspect(io, positionals, flags);
    case 'diff':
      return cmdDiff(io, positionals, flags);
    case 'fork':
      return cmdFork(io, positionals, flags);
    case 'seal':
      return cmdSeal(io, positionals, flags);
    case 'verify':
      return cmdVerify(io, positionals);
    default:
      io.error(`agenticstash: unknown command '${command}'\n`);
      io.error("run 'agenticstash help' for usage\n");
      return 64;
  }
}
