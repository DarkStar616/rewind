/**
 * A tiny, dependency-free argument parser for the `agenticstash` CLI.
 *
 * Splits an argv tail into positionals and `--flag value` / `--flag` pairs. No external parser, no
 * surprises: an unknown flag is just a flag, validation belongs to each command.
 *
 * @packageDocumentation
 */

/** Parsed CLI arguments: ordered positionals plus a flag map. */
export interface ParsedArgs {
  /** Non-flag arguments in order, for example the command and the input path. */
  readonly positionals: readonly string[];
  /** Flags; a bare `--json` is `true`, a `--at 5` is the string `'5'`. */
  readonly flags: Readonly<Record<string, string | boolean>>;
}

/** Parses an argv tail into {@link ParsedArgs}. */
export function parseArgs(argv: readonly string[]): ParsedArgs {
  const positionals: string[] = [];
  const flags: Record<string, string | boolean> = {};

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === undefined) {
      continue;
    }
    if (arg.startsWith('--')) {
      const key = arg.slice(2);
      const next = argv[i + 1];
      if (next !== undefined && !next.startsWith('--')) {
        flags[key] = next;
        i += 1;
      } else {
        flags[key] = true;
      }
    } else {
      positionals.push(arg);
    }
  }

  return { positionals, flags };
}

/** Reads a flag as a string, returning `fallback` when absent or boolean. */
export function flagString(
  flags: Readonly<Record<string, string | boolean>>,
  key: string,
  fallback: string,
): string {
  const value = flags[key];
  return typeof value === 'string' ? value : fallback;
}

/** Reads a flag as a finite number, returning `fallback` when absent or unparsable. */
export function flagNumber(
  flags: Readonly<Record<string, string | boolean>>,
  key: string,
  fallback: number,
): number {
  const value = flags[key];
  if (typeof value !== 'string') {
    return fallback;
  }
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}
