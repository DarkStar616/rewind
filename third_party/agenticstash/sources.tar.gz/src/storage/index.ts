/**
 * Storage for Agentic Stash recordings.
 *
 * {@link BlobStore} is a content-addressed table: identical payloads (a repeated tool response, the
 * same system prompt seen on every step) are stored once and referenced by hash, which is the
 * storage-efficiency lever the recorder relies on. {@link encodeRecording} and
 * {@link decodeRecording} move a {@link Recording} to and from a portable JSON string, validating
 * shape on the way in so a malformed file fails loudly with `ERR_INVALID_RECORDING`.
 *
 * @packageDocumentation
 */

import { AgenticStashError } from '../errors.js';
import { hashValue, stableStringify } from '../hash.js';
import type { Recording, RecordingStats } from '../types.js';

/** A content-addressed store that deduplicates structurally equal payloads. */
export class BlobStore {
  private readonly store = new Map<string, unknown>();

  /** Inserts a value and returns its content reference, deduplicating an identical payload. */
  put(value: unknown): string {
    const base = hashValue(value);
    const stable = stableStringify(value);
    let ref = base;
    let n = 0;
    while (this.store.has(ref)) {
      if (stableStringify(this.store.get(ref)) === stable) {
        return ref;
      }
      n += 1;
      ref = `${base}:${n}`;
    }
    this.store.set(ref, structuredClone(value));
    return ref;
  }

  /** Returns a defensive copy of the value at `ref`, throwing `ERR_NOT_FOUND` if absent. */
  get(ref: string): unknown {
    if (!this.store.has(ref)) {
      throw AgenticStashError.notFound(`no blob for ref '${ref}'`, { ref });
    }
    return structuredClone(this.store.get(ref));
  }

  /** Whether a value exists for `ref`. */
  has(ref: string): boolean {
    return this.store.has(ref);
  }

  /** Number of distinct blobs held. */
  size(): number {
    return this.store.size;
  }

  /** Exports the blob table as a plain record for serialization. */
  toRecord(): Record<string, unknown> {
    return Object.fromEntries(this.store);
  }

  /** Rebuilds a store from a serialized blob table. */
  static fromRecord(record: Readonly<Record<string, unknown>>): BlobStore {
    const store = new BlobStore();
    for (const [ref, value] of Object.entries(record)) {
      store.store.set(ref, value);
    }
    return store;
  }
}

/** Serializes a recording to a portable JSON string. */
export function encodeRecording(recording: Recording): string {
  return JSON.stringify(recording);
}

/** Validates one event's shape, throwing `ERR_INVALID_RECORDING` on any defect. */
function assertEvent(value: unknown, index: number): void {
  if (typeof value !== 'object' || value === null) {
    throw AgenticStashError.invalidRecording(`event ${index} is not an object`, { index });
  }
  const e = value as Record<string, unknown>;
  if (typeof e.seq !== 'number' || typeof e.ordinal !== 'number') {
    throw AgenticStashError.invalidRecording(`event ${index} has a non-numeric seq or ordinal`, {
      index,
    });
  }
  if (typeof e.channel !== 'string' || typeof e.key !== 'string') {
    throw AgenticStashError.invalidRecording(`event ${index} has a non-string channel or key`, {
      index,
    });
  }
  if (e.outcome !== 'return' && e.outcome !== 'throw') {
    throw AgenticStashError.invalidRecording(`event ${index} has an invalid outcome`, { index });
  }
  if (typeof e.ref !== 'string') {
    throw AgenticStashError.invalidRecording(`event ${index} has a non-string ref`, { index });
  }
}

/** Parses and validates a recording from a JSON string. */
export function decodeRecording(json: string): Recording {
  let parsed: unknown;
  try {
    parsed = JSON.parse(json);
  } catch (error) {
    throw AgenticStashError.invalidRecording('recording is not valid JSON', {
      cause: error instanceof Error ? error.message : String(error),
    });
  }
  if (typeof parsed !== 'object' || parsed === null) {
    throw AgenticStashError.invalidRecording('recording is not an object');
  }
  const r = parsed as Record<string, unknown>;
  if (r.version !== 1) {
    throw AgenticStashError.invalidRecording('unsupported recording version', {
      version: r.version,
    });
  }
  if (typeof r.id !== 'string') {
    throw AgenticStashError.invalidRecording('recording id must be a string');
  }
  if (!Array.isArray(r.events)) {
    throw AgenticStashError.invalidRecording('recording events must be an array');
  }
  r.events.forEach(assertEvent);
  if (typeof r.blobs !== 'object' || r.blobs === null || Array.isArray(r.blobs)) {
    throw AgenticStashError.invalidRecording('recording blobs must be an object');
  }
  if (typeof r.meta !== 'object' || r.meta === null || Array.isArray(r.meta)) {
    throw AgenticStashError.invalidRecording('recording meta must be an object');
  }
  return parsed as Recording;
}

/** Computes summary statistics for a recording. */
export function recordingStats(recording: Recording): RecordingStats {
  const channels: Record<string, number> = {};
  let throws = 0;
  for (const event of recording.events) {
    channels[event.channel] = (channels[event.channel] ?? 0) + 1;
    if (event.outcome === 'throw') {
      throws += 1;
    }
  }
  return {
    events: recording.events.length,
    channels,
    blobs: Object.keys(recording.blobs).length,
    throws,
  };
}

export type { RecordedEvent, Recording, RecordingStats } from '../types.js';
