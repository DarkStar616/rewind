/**
 * Deterministic, dependency-free content hashing for blob deduplication.
 *
 * {@link stableStringify} serializes a JSON value with sorted object keys so two structurally equal
 * values produce identical strings regardless of key insertion order. {@link hashValue} runs that
 * through a 53-bit cyrb hash rendered as a 14-character hex string. This is a content-addressing
 * hash for deduplication, not a cryptographic primitive; the blob store compares full content on a
 * hash hit, so a collision never corrupts a recording.
 *
 * @packageDocumentation
 */

import { AgenticStashError } from './errors.js';

/**
 * Serializes a JSON-compatible value with deterministic (sorted) object key order.
 *
 * Throws `ERR_INVALID_INPUT` for values a recording cannot persist (functions, symbols, bigint) or
 * for circular references, so non-replayable values fail loudly at capture time, not on load.
 */
export function stableStringify(value: unknown): string {
  const seen = new WeakSet<object>();
  const encode = (input: unknown): string => {
    if (input === null) {
      return 'null';
    }
    const kind = typeof input;
    if (kind === 'string') {
      return JSON.stringify(input);
    }
    if (kind === 'number') {
      return Number.isFinite(input as number) ? JSON.stringify(input) : 'null';
    }
    if (kind === 'boolean') {
      return (input as boolean) ? 'true' : 'false';
    }
    if (kind === 'undefined') {
      return '"__undefined__"';
    }
    if (kind === 'bigint' || kind === 'function' || kind === 'symbol') {
      throw AgenticStashError.invalidInput(
        `cannot record a value of type '${kind}'; recordings must be JSON-serializable`,
        { kind },
      );
    }
    const obj = input as object;
    if (seen.has(obj)) {
      throw AgenticStashError.invalidInput('cannot record a circular reference');
    }
    seen.add(obj);
    let out: string;
    if (Array.isArray(obj)) {
      out = `[${obj.map((item) => encode(item)).join(',')}]`;
    } else {
      const keys = Object.keys(obj as Record<string, unknown>).sort();
      const parts: string[] = [];
      for (const k of keys) {
        const v = (obj as Record<string, unknown>)[k];
        if (v === undefined) {
          continue;
        }
        parts.push(`${JSON.stringify(k)}:${encode(v)}`);
      }
      out = `{${parts.join(',')}}`;
    }
    seen.delete(obj);
    return out;
  };
  return encode(value);
}

/** Hashes a string with cyrb53 and renders the 53-bit digest as a 14-character hex string. */
export function hashString(text: string, seed = 0): string {
  let h1 = 0xdeadbeef ^ seed;
  let h2 = 0x41c6ce57 ^ seed;
  for (let i = 0; i < text.length; i += 1) {
    const ch = text.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507);
  h1 ^= Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507);
  h2 ^= Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  const digest = 4294967296 * (2097151 & h2) + (h1 >>> 0);
  return digest.toString(16).padStart(14, '0');
}

/** Hashes any JSON-serializable value by its stable serialization. */
export function hashValue(value: unknown): string {
  return hashString(stableStringify(value));
}
