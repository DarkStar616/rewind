/**
 * A structural bridge for recording and replaying MCP tool calls.
 *
 * MCP tool responses depend on external state and are a primary source of non-determinism in agent
 * runs. This module records each call's result on the `'mcp'` channel keyed by tool name and serves
 * it back on replay, so a debugging session never re-hits a live tool. It is duck-typed: it imports
 * no MCP SDK and only relies on a `callTool({ name, arguments })` shape, so it works with any client
 * that matches it.
 *
 * @packageDocumentation
 */

import type { InterceptOptions, Stash } from '../types.js';

/** The minimal shape of an MCP tool invocation. */
export interface McpToolCall {
  /** The tool name. */
  readonly name: string;
  /** The tool arguments, recorded as the call input so replay can detect divergence. */
  readonly arguments?: unknown;
}

/** The minimal shape of an MCP client this bridge can wrap. */
export interface McpClientLike {
  /** Invokes a tool and resolves with its result. */
  callTool(call: McpToolCall): Promise<unknown>;
}

/**
 * Wraps an {@link McpClientLike} so every `callTool` is recorded and replayed through the stash.
 *
 * In record mode the wrapped client calls through to the real client and captures the result; in
 * replay mode it returns the recorded result for that tool and arguments without touching the
 * network.
 */
export function interceptMcpClient(stash: Stash, client: McpClientLike): McpClientLike {
  return {
    callTool: (call: McpToolCall) =>
      stash.intercept('mcp', call.name, () => client.callTool(call), {
        input: call.arguments,
      } as InterceptOptions),
  };
}

/**
 * Wraps a single MCP tool handler so its result is recorded and replayed on the `'mcp'` channel.
 *
 * Use this when you hold the handler directly rather than a client object.
 */
export function recordMcpTool<A, R>(
  stash: Stash,
  name: string,
  handler: (args: A) => Promise<R> | R,
): (args: A) => Promise<R> {
  return (args: A) =>
    stash.intercept('mcp', name, () => handler(args), { input: args } as InterceptOptions);
}
