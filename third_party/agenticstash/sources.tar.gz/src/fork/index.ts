/**
 * The fork engine: derive a new recording that diverges from an existing one at a chosen point.
 *
 * Forking keeps every event before `at`, optionally overrides the decision at `at` with a new value,
 * and drops the tail. Replaying the fork serves the shared prefix deterministically, applies the
 * changed decision, and then runs live from the fork point, so a single recorded run becomes the
 * root of an alternate branch ("what if the planner had chosen B here?") without re-running the
 * expensive, non-deterministic prefix.
 *
 * @packageDocumentation
 */

import { AgenticStashError } from '../errors.js';
import { hashValue } from '../hash.js';
import type { RecordedEvent, Recording } from '../types.js';

/** Options for {@link fork}. */
export interface ForkOptions {
  /** The sequence index where the fork diverges. Events before it are kept. */
  readonly at: number;
  /** When present, the event at `at` is kept with its value replaced by `value` (a forced decision). */
  readonly override?: { readonly value: unknown };
  /** Id for the forked recording; defaults to `<id>_fork<at>`. */
  readonly id?: string;
}

/** Creates a forked {@link Recording} that diverges from `recording` at `options.at`. */
export function fork(recording: Recording, options: ForkOptions): Recording {
  const { at } = options;
  if (!Number.isInteger(at) || at < 0 || at > recording.events.length) {
    throw AgenticStashError.invalidInput(
      `fork point ${at} is out of range [0, ${recording.events.length}]`,
      { at, length: recording.events.length },
    );
  }

  const prefix = recording.events.filter((event) => event.seq < at);
  const blobs: Record<string, unknown> = {};
  const keep = (ref: string | undefined): void => {
    if (ref !== undefined && ref in recording.blobs) {
      blobs[ref] = recording.blobs[ref];
    }
  };
  for (const event of prefix) {
    keep(event.ref);
    keep(event.inputRef);
  }

  let events: RecordedEvent[] = prefix;
  if (options.override) {
    const target = recording.events.find((event) => event.seq === at);
    if (!target) {
      throw AgenticStashError.invalidInput(`cannot override: no event at seq ${at}`, { at });
    }
    const ref = hashValue(options.override.value);
    blobs[ref] = structuredClone(options.override.value);
    keep(target.inputRef);
    const modified: RecordedEvent = { ...target, outcome: 'return', ref };
    events = [...prefix, modified];
  }

  return {
    version: 1,
    id: options.id ?? `${recording.id}_fork${at}`,
    events,
    blobs,
    meta: { ...recording.meta, forkedFrom: recording.id, forkAt: at },
  };
}
