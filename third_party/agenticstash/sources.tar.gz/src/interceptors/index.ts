/**
 * Framework-agnostic interceptors that route common non-determinism sources through a {@link Stash}.
 *
 * These are thin conveniences over {@link Stash.intercept}: a clock whose reads are recorded and
 * replayed, a seeded pseudo-random generator whose seed is recorded so the exact sequence replays,
 * and {@link wrap} / {@link wrapSync} to turn any function (a model call, a tool, an HTTP fetch) into
 * a recorded-and-replayable one keyed by a stable name. Nothing here imports a provider SDK, so the
 * same mechanism covers any framework.
 *
 * @packageDocumentation
 */

import { hashString } from '../hash.js';
import type { Channel, InterceptOptions, Stash } from '../types.js';

/** A clock whose reads are recorded and replayed through a stash. */
export interface DeterministicClock {
  /** Returns the current time, recorded on the first run and replayed thereafter. */
  now(): number;
}

/** A seeded pseudo-random generator whose seed is recorded so its sequence is reproducible. */
export interface SeededRandom {
  /** The seed in effect (the supplied one, or one derived deterministically from the recording id). */
  readonly seed: number;
  /** Returns the next pseudo-random float in [0, 1). */
  next(): number;
}

/** The mulberry32 generator: a small, fast, fully deterministic PRNG. */
function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * Creates a {@link DeterministicClock} on the `'clock'` channel.
 *
 * In record mode every `now()` reads and records `source()`. In replay mode it returns the recorded
 * reads in order, so time-dependent logic sees exactly the timeline of the original run.
 */
export function createDeterministicClock(
  stash: Stash,
  source: () => number = () => Date.now(),
  key = 'now',
): DeterministicClock {
  return {
    now: () => stash.interceptSync('clock', key, source),
  };
}

/**
 * Creates a {@link SeededRandom} on the `'random'` channel.
 *
 * The seed is recorded once (replay reads it back), and all draws come from a local PRNG, so the
 * full sequence reproduces without recording every number. Supply a seed for reproducibility across
 * fresh recordings; otherwise one is derived deterministically from the recording id.
 */
export function createSeededRandom(stash: Stash, seed?: number, key = 'seed'): SeededRandom {
  const fallback =
    Number.parseInt(hashString(`${stash.recording().id}:random`).slice(0, 8), 16) >>> 0;
  const resolved = stash.value('random', key, typeof seed === 'number' ? seed >>> 0 : fallback);
  const generator = mulberry32(resolved);
  return {
    seed: resolved,
    next: () => generator(),
  };
}

/**
 * Wraps an async function so each call is recorded and replayed on `channel`/`key`.
 *
 * The argument is recorded as the call input, so a replay against changed code raises a divergence.
 * On replay the wrapped function is not invoked; the recorded result (or error) is returned.
 */
export function wrap<I, O>(
  stash: Stash,
  channel: Channel,
  key: string,
  fn: (input: I) => Promise<O> | O,
): (input: I) => Promise<O> {
  return (input: I) =>
    stash.intercept(channel, key, () => fn(input), { input } as InterceptOptions);
}

/** Synchronous form of {@link wrap}. */
export function wrapSync<I, O>(
  stash: Stash,
  channel: Channel,
  key: string,
  fn: (input: I) => O,
): (input: I) => O {
  return (input: I) =>
    stash.interceptSync(channel, key, () => fn(input), { input } as InterceptOptions);
}
