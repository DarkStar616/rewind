import { describe, expect, it } from 'vitest';
import { AgenticStashError } from '../src/errors.js';
import { createRecorder } from '../src/record/index.js';
import {
  BlobStore,
  decodeRecording,
  encodeRecording,
  recordingStats,
} from '../src/storage/index.js';
import type { Recording } from '../src/types.js';

describe('BlobStore', () => {
  it('deduplicates structurally equal payloads', () => {
    const store = new BlobStore();
    const a = store.put({ x: 1, y: 2 });
    const b = store.put({ y: 2, x: 1 });
    expect(a).toBe(b);
    expect(store.size()).toBe(1);
  });

  it('returns defensive copies so callers cannot mutate stored blobs', () => {
    const store = new BlobStore();
    const ref = store.put({ items: [1] });
    const first = store.get(ref) as { items: number[] };
    first.items.push(2);
    expect((store.get(ref) as { items: number[] }).items).toEqual([1]);
  });

  it('throws ERR_NOT_FOUND for a missing ref', () => {
    expect(() => new BlobStore().get('nope')).toThrow(AgenticStashError);
  });
});

describe('encode/decode', () => {
  const sample = (): Recording => {
    const rec = createRecorder({ id: 'r1' });
    rec.value('llm', 'plan', { ok: true });
    return rec.recording();
  };

  it('round-trips a recording', () => {
    const recording = sample();
    const restored = decodeRecording(encodeRecording(recording));
    expect(restored).toEqual(recording);
  });

  it('rejects invalid JSON', () => {
    expect(() => decodeRecording('{not json')).toThrow(/valid JSON/);
  });

  it('rejects an unsupported version', () => {
    expect(() => decodeRecording(JSON.stringify({ version: 2 }))).toThrow(AgenticStashError);
  });

  it('rejects a malformed event', () => {
    const bad = JSON.stringify({
      version: 1,
      id: 'x',
      events: [{ seq: 'no' }],
      blobs: {},
      meta: {},
    });
    expect(() => decodeRecording(bad)).toThrow(/ERR_INVALID_RECORDING|seq/);
  });
});

describe('recordingStats', () => {
  it('counts events, channels, blobs, and throws', () => {
    const rec = createRecorder({ id: 'r1' });
    rec.value('llm', 'a', 1);
    rec.value('llm', 'b', 2);
    rec.value('tool', 'c', 2);
    const stats = recordingStats(rec.recording());
    expect(stats.events).toBe(3);
    expect(stats.channels).toEqual({ llm: 2, tool: 1 });
    expect(stats.blobs).toBe(2);
    expect(stats.throws).toBe(0);
  });
});
