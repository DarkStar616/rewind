/**
 * Deterministic helpers for the test suite. No randomness, so assertions are stable.
 */

import type { CliIO } from '../src/cli/commands.js';

/** A captured in-memory CLI surface for driving runCli without a process. */
export interface MemoryCli {
  /** The injectable IO surface. */
  readonly io: CliIO;
  /** Everything written to stdout, joined. */
  out(): string;
  /** Everything written to stderr, joined. */
  err(): string;
  /** Files written via `writeFile`, by path. */
  readonly written: Record<string, string>;
}

/** Builds an in-memory {@link CliIO} that reads from `files` and captures all output and writes. */
export function memoryCli(argv: readonly string[], files: Record<string, string> = {}): MemoryCli {
  const outChunks: string[] = [];
  const errChunks: string[] = [];
  const written: Record<string, string> = {};
  const io: CliIO = {
    argv,
    write: (text) => {
      outChunks.push(text);
    },
    error: (text) => {
      errChunks.push(text);
    },
    readFile: (path) => {
      const content = files[path];
      if (content === undefined) {
        throw new Error(`ENOENT: no such file '${path}'`);
      }
      return content;
    },
    writeFile: (path, text) => {
      written[path] = text;
    },
  };
  return {
    io,
    out: () => outChunks.join(''),
    err: () => errChunks.join(''),
    written,
  };
}

/**
 * A deterministic fake async "model" call: returns a fixed reply derived from the prompt, and counts
 * how many times it actually ran, so a test can prove replay did not call through.
 */
export function fakeModel(): { call: (prompt: string) => Promise<string>; calls: () => number } {
  let count = 0;
  return {
    call: (prompt: string) => {
      count += 1;
      return Promise.resolve(`reply:${prompt}:${count}`);
    },
    calls: () => count,
  };
}
