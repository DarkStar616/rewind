import { describe, expect, it } from 'vitest';
import { createStash, loadStash } from '../src/index.js';
import { fakeModel } from './helpers.js';

/** One agent step written once against the stash, used for both record and replay. */
async function runAgent(
  stash: ReturnType<typeof createStash>,
  model: (p: string) => Promise<string>,
) {
  const a = await stash.intercept('llm', 'step1', () => model('plan'), { input: 'plan' });
  const b = await stash.intercept('llm', 'step2', () => model('act'), { input: 'act' });
  return `${a}|${b}`;
}

describe('createStash', () => {
  it('records a run, then replays it deterministically without calling through', async () => {
    const model = fakeModel();
    const recordStash = createStash({ id: 'run-1' });
    const recorded = await runAgent(recordStash, model.call);
    expect(model.calls()).toBe(2);

    const replayStash = loadStash(recordStash.save());
    const replayed = await runAgent(replayStash, model.call);
    expect(replayed).toBe(recorded);
    expect(model.calls()).toBe(2); // unchanged: replay did not call the model
    expect(replayStash.mode).toBe('replay');
    expect(replayStash.consumed()).toBe(2);
  });

  it('exposes record mode defaults', () => {
    const stash = createStash({ id: 'r' });
    expect(stash.mode).toBe('record');
    expect(stash.consumed()).toBe(0);
    expect(stash.remaining()).toEqual([]);
  });

  it('records and replays a synchronous value', () => {
    const recordStash = createStash({ id: 'r' });
    expect(recordStash.interceptSync('env', 'flag', () => true)).toBe(true);
    const replayStash = loadStash(recordStash.save());
    expect(replayStash.interceptSync('env', 'flag', () => false)).toBe(true);
  });

  it('records a value() and replays it', () => {
    const recordStash = createStash({ id: 'r' });
    recordStash.value('seed', 's', 7);
    const replayStash = loadStash(recordStash.save());
    expect(replayStash.value('seed', 's', 999)).toBe(7);
  });

  it('detects divergence on replay when inputs change', async () => {
    const recordStash = createStash({ id: 'r' });
    await recordStash.intercept('llm', 'plan', () => Promise.resolve('x'), { input: 'a' });
    const replayStash = loadStash(recordStash.save());
    await expect(
      replayStash.intercept('llm', 'plan', () => Promise.resolve('y'), { input: 'b' }),
    ).rejects.toThrow(/ERR_DIVERGENCE|does not match/);
  });
});
