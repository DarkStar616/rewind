import { describe, expect, it } from 'vitest';
import { runCli } from '../src/cli/commands.js';
import { createRecorder } from '../src/record/index.js';
import { sealRecording } from '../src/seal/index.js';
import { decodeRecording, encodeRecording } from '../src/storage/index.js';
import { memoryCli } from './helpers.js';

function sampleJson(values: Array<[string, string, unknown]>): string {
  const rec = createRecorder({ id: 'sample' });
  for (const [channel, key, value] of values) {
    rec.value(channel, key, value);
  }
  return encodeRecording(rec.recording());
}

describe('runCli', () => {
  it('prints the version', async () => {
    const cli = memoryCli(['version']);
    expect(await runCli(cli.io)).toBe(0);
    expect(cli.out().trim()).toBe('1.0.0');
  });

  it('prints help with no command', async () => {
    const cli = memoryCli([]);
    expect(await runCli(cli.io)).toBe(0);
    expect(cli.out()).toContain('agenticstash');
  });

  it('exits 64 on an unknown command', async () => {
    const cli = memoryCli(['frobnicate']);
    expect(await runCli(cli.io)).toBe(64);
  });

  it('inspects a recording', async () => {
    const cli = memoryCli(['inspect', 'r.json'], { 'r.json': sampleJson([['llm', 'plan', 'A']]) });
    expect(await runCli(cli.io)).toBe(0);
    expect(cli.out()).toContain('recording: sample');
    expect(cli.out()).toContain('events:');
  });

  it('inspects as json', async () => {
    const cli = memoryCli(['inspect', 'r.json', '--json'], {
      'r.json': sampleJson([['llm', 'plan', 'A']]),
    });
    expect(await runCli(cli.io)).toBe(0);
    expect(JSON.parse(cli.out())).toMatchObject({ id: 'sample', events: 1 });
  });

  it('exits 66 when the file is unreadable', async () => {
    const cli = memoryCli(['inspect', 'missing.json']);
    expect(await runCli(cli.io)).toBe(66);
  });

  it('exits 65 on an invalid recording', async () => {
    const cli = memoryCli(['inspect', 'bad.json'], { 'bad.json': '{not json' });
    expect(await runCli(cli.io)).toBe(65);
  });

  it('diffs two identical recordings', async () => {
    const json = sampleJson([['llm', 'plan', 'A']]);
    const cli = memoryCli(['diff', 'a.json', 'b.json'], { 'a.json': json, 'b.json': json });
    expect(await runCli(cli.io)).toBe(0);
    expect(cli.out()).toContain('identical');
  });

  it('diffs two diverging recordings', async () => {
    const cli = memoryCli(['diff', 'a.json', 'b.json'], {
      'a.json': sampleJson([['llm', 'plan', 'A']]),
      'b.json': sampleJson([['llm', 'plan', 'B']]),
    });
    expect(await runCli(cli.io)).toBe(0);
    expect(cli.out()).toContain('first divergence');
  });

  it('forks a recording to a file', async () => {
    const cli = memoryCli(['fork', 'r.json', '--at', '1', '--out', 'forked.json'], {
      'r.json': sampleJson([
        ['llm', 'plan', 'A'],
        ['llm', 'plan', 'B'],
      ]),
    });
    expect(await runCli(cli.io)).toBe(0);
    expect(cli.written['forked.json']).toContain('"version":1');
  });

  it('exits 64 when fork has no --at', async () => {
    const cli = memoryCli(['fork', 'r.json'], { 'r.json': sampleJson([['llm', 'plan', 'A']]) });
    expect(await runCli(cli.io)).toBe(64);
  });

  it('exits 65 when the fork point is out of range', async () => {
    const cli = memoryCli(['fork', 'r.json', '--at', '99'], {
      'r.json': sampleJson([['llm', 'plan', 'A']]),
    });
    expect(await runCli(cli.io)).toBe(65);
  });

  it('seals a recording to a file', async () => {
    const cli = memoryCli(['seal', 'r.json', '--out', 'r.seal.json'], {
      'r.json': sampleJson([['llm', 'plan', 'A']]),
    });
    expect(await runCli(cli.io)).toBe(0);
    expect(cli.written['r.seal.json']).toContain('"algorithm": "SHA-256"');
  });

  it('verifies a sealed recording and exits 1 when tampered', async () => {
    const json = sampleJson([['llm', 'plan', 'A']]);
    const seal = JSON.stringify(await sealRecording(decodeRecording(json)));

    const ok = memoryCli(['verify', 'r.json', 'r.seal.json'], {
      'r.json': json,
      'r.seal.json': seal,
    });
    expect(await runCli(ok.io)).toBe(0);
    expect(ok.out()).toContain('valid:');

    const tampered = sampleJson([['llm', 'plan', 'TAMPERED']]);
    const bad = memoryCli(['verify', 'r.json', 'r.seal.json'], {
      'r.json': tampered,
      'r.seal.json': seal,
    });
    expect(await runCli(bad.io)).toBe(1);
    expect(bad.err()).toContain('INVALID');
  });
});
