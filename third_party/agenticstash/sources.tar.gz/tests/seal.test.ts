import { describe, expect, it } from 'vitest';
import { createRecorder } from '../src/record/index.js';
import { sealRecording, verifyRecording } from '../src/seal/index.js';
import type { Recording } from '../src/types.js';

function build(values: Array<[string, string, unknown]>): Recording {
  const rec = createRecorder({ id: 'sealed' });
  for (const [channel, key, value] of values) {
    rec.value(channel, key, value);
  }
  return rec.recording();
}

describe('sealRecording / verifyRecording', () => {
  it('produces a SHA-256 hex root and verifies an unmodified recording', async () => {
    const recording = build([
      ['llm', 'plan', 'A'],
      ['tool', 'search', { hits: 3 }],
    ]);
    const seal = await sealRecording(recording);
    expect(seal.algorithm).toBe('SHA-256');
    expect(seal.root).toMatch(/^[0-9a-f]{64}$/);
    expect(seal.count).toBe(2);
    const result = await verifyRecording(recording, seal);
    expect(result.valid).toBe(true);
  });

  it('is deterministic: the same recording seals to the same root', async () => {
    const a = await sealRecording(build([['llm', 'plan', 'A']]));
    const b = await sealRecording(build([['llm', 'plan', 'A']]));
    expect(a.root).toBe(b.root);
  });

  it('detects a tampered recorded value', async () => {
    const original = build([['llm', 'plan', 'A']]);
    const seal = await sealRecording(original);
    const tampered = build([['llm', 'plan', 'A-TAMPERED']]);
    const result = await verifyRecording(tampered, seal);
    expect(result.valid).toBe(false);
    expect(result.reason).toMatch(/modified|root/);
  });

  it('detects a changed event count', async () => {
    const seal = await sealRecording(build([['llm', 'plan', 'A']]));
    const result = await verifyRecording(
      build([
        ['llm', 'plan', 'A'],
        ['llm', 'plan', 'B'],
      ]),
      seal,
    );
    expect(result.valid).toBe(false);
    expect(result.reason).toMatch(/count/);
  });

  it('detects reordered events', async () => {
    const seal = await sealRecording(
      build([
        ['llm', 'a', 1],
        ['llm', 'b', 2],
      ]),
    );
    const reordered = build([
      ['llm', 'b', 2],
      ['llm', 'a', 1],
    ]);
    expect((await verifyRecording(reordered, seal)).valid).toBe(false);
  });

  it('seals an empty recording', async () => {
    const seal = await sealRecording(build([]));
    expect(seal.count).toBe(0);
    expect((await verifyRecording(build([]), seal)).valid).toBe(true);
  });
});
