import { describe, expect, it } from 'vitest';
import { AgenticStashError } from '../src/errors.js';
import { hashString, hashValue, stableStringify } from '../src/hash.js';

describe('stableStringify', () => {
  it('is independent of object key insertion order', () => {
    expect(stableStringify({ a: 1, b: 2 })).toBe(stableStringify({ b: 2, a: 1 }));
  });

  it('omits undefined object properties', () => {
    expect(stableStringify({ a: 1, b: undefined })).toBe(stableStringify({ a: 1 }));
  });

  it('preserves array order', () => {
    expect(stableStringify([1, 2, 3])).not.toBe(stableStringify([3, 2, 1]));
  });

  it('rejects non-serializable values', () => {
    expect(() => stableStringify(() => 0)).toThrow(AgenticStashError);
    expect(() => stableStringify(10n)).toThrow(/JSON-serializable/);
  });

  it('rejects circular references', () => {
    const a: Record<string, unknown> = {};
    a.self = a;
    expect(() => stableStringify(a)).toThrow(/circular/);
  });
});

describe('hashValue', () => {
  it('is stable for equal values regardless of key order', () => {
    expect(hashValue({ x: 1, y: [2, 3] })).toBe(hashValue({ y: [2, 3], x: 1 }));
  });

  it('differs for different values', () => {
    expect(hashValue({ x: 1 })).not.toBe(hashValue({ x: 2 }));
  });

  it('renders a fixed-width hex digest', () => {
    expect(hashString('anything')).toMatch(/^[0-9a-f]{14}$/);
  });
});
