import { describe, expect, it } from 'vitest';
import { createStash, loadStash } from '../src/index.js';
import {
  createDeterministicClock,
  createSeededRandom,
  wrap,
  wrapSync,
} from '../src/interceptors/index.js';

describe('createDeterministicClock', () => {
  it('records clock reads and replays the exact timeline', () => {
    let t = 1000;
    const source = () => {
      t += 5;
      return t;
    };
    const recordStash = createStash({ id: 'clock' });
    const recClock = createDeterministicClock(recordStash, source);
    const recorded = [recClock.now(), recClock.now(), recClock.now()];
    expect(recorded).toEqual([1005, 1010, 1015]);

    const replayStash = loadStash(recordStash.save());
    const replayClock = createDeterministicClock(replayStash, () => {
      throw new Error('clock should not be read on replay');
    });
    expect([replayClock.now(), replayClock.now(), replayClock.now()]).toEqual(recorded);
  });
});

describe('createSeededRandom', () => {
  it('reproduces the exact sequence across record and replay', () => {
    const recordStash = createStash({ id: 'rng' });
    const recRng = createSeededRandom(recordStash, 42);
    const recorded = [recRng.next(), recRng.next(), recRng.next()];

    const replayStash = loadStash(recordStash.save());
    const replayRng = createSeededRandom(replayStash);
    expect(replayRng.seed).toBe(42);
    expect([replayRng.next(), replayRng.next(), replayRng.next()]).toEqual(recorded);
  });

  it('derives a deterministic seed when none is supplied', () => {
    const a = createSeededRandom(createStash({ id: 'same' }));
    const b = createSeededRandom(createStash({ id: 'same' }));
    expect(a.seed).toBe(b.seed);
  });
});

describe('wrap', () => {
  it('records and replays an async function by name', async () => {
    let calls = 0;
    const fn = (p: string) => {
      calls += 1;
      return Promise.resolve(`out:${p}`);
    };
    const recordStash = createStash({ id: 'w' });
    const recorded = await wrap(recordStash, 'llm', 'call', fn)('hi');
    expect(recorded).toBe('out:hi');

    const replayStash = loadStash(recordStash.save());
    const replayed = await wrap(replayStash, 'llm', 'call', fn)('hi');
    expect(replayed).toBe('out:hi');
    expect(calls).toBe(1);
  });

  it('wraps a synchronous function', () => {
    const recordStash = createStash({ id: 'w' });
    expect(wrapSync(recordStash, 'env', 'read', (k: string) => `v:${k}`)('home')).toBe('v:home');
  });
});
