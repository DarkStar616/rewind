import { describe, expect, it } from 'vitest';
import { AgenticStashError } from '../src/errors.js';
import { createRecorder } from '../src/record/index.js';
import { createReplayer } from '../src/replay/index.js';

function recording() {
  const rec = createRecorder({ id: 'r1' });
  rec.value('llm', 'plan', { step: 'A' }, { input: 'prompt-1' });
  // The recorder is transparent: it captures the throw and re-throws it, so the fixture builder
  // must swallow the expected error while the event is recorded.
  try {
    rec.record('tool', 'search', () => {
      throw new Error('rate limited');
    });
  } catch {
    // expected: the throw was recorded
  }
  return rec.recording();
}

describe('createReplayer', () => {
  it('serves recorded values in order without calling a producer', () => {
    const replayer = createReplayer(recording());
    let called = false;
    const value = replayer.replay('llm', 'plan', () => {
      called = true;
      return { step: 'LIVE' };
    });
    expect(value).toEqual({ step: 'A' });
    expect(called).toBe(false);
  });

  it('re-throws a recorded error', () => {
    const replayer = createReplayer(recording());
    expect(() => replayer.replay('tool', 'search')).toThrow('rate limited');
  });

  it('raises ERR_DIVERGENCE when the input hash changes', () => {
    const replayer = createReplayer(recording());
    expect(() => replayer.replay('llm', 'plan', undefined, { input: 'prompt-CHANGED' })).toThrow(
      AgenticStashError,
    );
  });

  it('passes when the input matches', () => {
    const replayer = createReplayer(recording());
    expect(replayer.replay('llm', 'plan', undefined, { input: 'prompt-1' })).toEqual({ step: 'A' });
  });

  it('skips the input check when strict is false', () => {
    const replayer = createReplayer(recording(), { strict: false });
    expect(replayer.replay('llm', 'plan', undefined, { input: 'whatever' })).toEqual({ step: 'A' });
  });

  it('raises ERR_RECORDING_EXHAUSTED past the end', () => {
    const replayer = createReplayer(recording());
    replayer.replay('llm', 'plan');
    expect(() => replayer.replay('llm', 'plan')).toThrow(/ERR_RECORDING_EXHAUSTED|end of recorded/);
  });

  it('runs a live tail when allowed', () => {
    const replayer = createReplayer(recording());
    replayer.replay('llm', 'plan');
    const tail = replayer.replay('llm', 'plan', () => 'live', { allowLiveTail: true });
    expect(tail).toBe('live');
  });

  it('tracks consumed and remaining', () => {
    const replayer = createReplayer(recording());
    expect(replayer.consumed()).toBe(0);
    expect(replayer.remaining()).toHaveLength(2);
    replayer.replay('llm', 'plan');
    expect(replayer.consumed()).toBe(1);
    expect(replayer.remaining()).toHaveLength(1);
  });

  it('replays async values', async () => {
    const replayer = createReplayer(recording());
    await expect(replayer.replayAsync('llm', 'plan')).resolves.toEqual({ step: 'A' });
  });
});
