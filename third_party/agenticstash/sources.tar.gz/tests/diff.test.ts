import { describe, expect, it } from 'vitest';
import { diffRecordings } from '../src/diff/index.js';
import { createRecorder } from '../src/record/index.js';

function build(values: Array<[string, string, unknown]>) {
  const rec = createRecorder({ id: 'r' });
  for (const [channel, key, value] of values) {
    rec.value(channel, key, value);
  }
  return rec.recording();
}

describe('diffRecordings', () => {
  it('reports identical recordings', () => {
    const a = build([['llm', 'plan', 'A']]);
    const b = build([['llm', 'plan', 'A']]);
    expect(diffRecordings(a, b).identical).toBe(true);
  });

  it('detects a changed value and the first divergence', () => {
    const a = build([
      ['llm', 'plan', 'A'],
      ['llm', 'plan', 'B'],
    ]);
    const b = build([
      ['llm', 'plan', 'A'],
      ['llm', 'plan', 'B-PRIME'],
    ]);
    const result = diffRecordings(a, b);
    expect(result.identical).toBe(false);
    expect(result.changed).toHaveLength(1);
    expect(result.changed[0]?.before).toBe('B');
    expect(result.changed[0]?.after).toBe('B-PRIME');
    expect(result.firstDivergence).toEqual({ channel: 'llm', key: 'plan', ordinal: 1 });
  });

  it('detects added and removed events', () => {
    const a = build([['llm', 'plan', 'A']]);
    const b = build([
      ['llm', 'plan', 'A'],
      ['tool', 'search', 'R'],
    ]);
    const result = diffRecordings(a, b);
    expect(result.added).toHaveLength(1);
    expect(result.added[0]?.channel).toBe('tool');
    expect(diffRecordings(b, a).removed).toHaveLength(1);
  });
});
