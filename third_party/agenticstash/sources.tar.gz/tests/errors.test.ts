import { describe, expect, it } from 'vitest';
import { AgenticStashError, isAgenticStashError } from '../src/errors.js';

describe('AgenticStashError', () => {
  it('carries a stable code and optional details', () => {
    const error = AgenticStashError.divergence('boom', { seq: 3 });
    expect(error.code).toBe('ERR_DIVERGENCE');
    expect(error.details).toEqual({ seq: 3 });
    expect(error.name).toBe('AgenticStashError');
    expect(error).toBeInstanceOf(Error);
  });

  it('omits details when not provided', () => {
    expect(AgenticStashError.exhausted('done').details).toBeUndefined();
  });

  it('exposes a working type guard', () => {
    expect(isAgenticStashError(AgenticStashError.invalidInput('x'))).toBe(true);
    expect(isAgenticStashError(new Error('x'))).toBe(false);
  });

  it('builds each documented code', () => {
    expect(AgenticStashError.invalidRecording('x').code).toBe('ERR_INVALID_RECORDING');
    expect(AgenticStashError.invalidInput('x').code).toBe('ERR_INVALID_INPUT');
    expect(AgenticStashError.notFound('x').code).toBe('ERR_NOT_FOUND');
  });
});
