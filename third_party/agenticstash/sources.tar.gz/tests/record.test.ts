import { describe, expect, it } from 'vitest';
import { createRecorder } from '../src/record/index.js';

describe('createRecorder', () => {
  it('captures a returned value and passes it through unchanged', () => {
    const rec = createRecorder({ id: 'r1' });
    const out = rec.record('llm', 'plan', () => ({ answer: 42 }));
    expect(out).toEqual({ answer: 42 });
    const recording = rec.recording();
    expect(recording.events).toHaveLength(1);
    expect(recording.events[0]?.outcome).toBe('return');
  });

  it('captures a thrown error and re-throws it', () => {
    const rec = createRecorder({ id: 'r1' });
    expect(() =>
      rec.record('tool', 'search', () => {
        throw new Error('upstream down');
      }),
    ).toThrow('upstream down');
    expect(rec.recording().events[0]?.outcome).toBe('throw');
  });

  it('assigns per-(channel,key) ordinals and a global sequence', () => {
    const rec = createRecorder({ id: 'r1' });
    rec.value('llm', 'plan', 'a');
    rec.value('llm', 'plan', 'b');
    rec.value('tool', 'plan', 'c');
    const events = rec.recording().events;
    expect(events.map((e) => e.ordinal)).toEqual([0, 1, 0]);
    expect(events.map((e) => e.seq)).toEqual([0, 1, 2]);
  });

  it('records the input hash when an input is supplied', () => {
    const rec = createRecorder({ id: 'r1' });
    rec.record('llm', 'plan', () => 'ok', { input: { prompt: 'hi' } });
    expect(rec.recording().events[0]?.inputRef).toBeTypeOf('string');
  });

  it('stamps at only when a clock is given', () => {
    const withClock = createRecorder({ id: 'r1', now: () => 123 });
    withClock.value('llm', 'a', 1);
    expect(withClock.recording().events[0]?.at).toBe(123);
    const without = createRecorder({ id: 'r2' });
    without.value('llm', 'a', 1);
    expect(without.recording().events[0]?.at).toBeUndefined();
  });

  it('records an async producer', async () => {
    const rec = createRecorder({ id: 'r1' });
    const out = await rec.recordAsync('llm', 'plan', () => Promise.resolve('done'));
    expect(out).toBe('done');
    expect(rec.size()).toBe(1);
  });
});
