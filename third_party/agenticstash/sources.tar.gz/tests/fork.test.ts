import { describe, expect, it } from 'vitest';
import { AgenticStashError } from '../src/errors.js';
import { fork } from '../src/fork/index.js';
import { createRecorder } from '../src/record/index.js';
import { createReplayer } from '../src/replay/index.js';

function recording() {
  const rec = createRecorder({ id: 'base' });
  rec.value('llm', 'plan', 'A');
  rec.value('llm', 'plan', 'B');
  rec.value('llm', 'plan', 'C');
  return rec.recording();
}

describe('fork', () => {
  it('truncates the tail at the fork point', () => {
    const forked = fork(recording(), { at: 1 });
    expect(forked.events).toHaveLength(1);
    expect(forked.id).toBe('base_fork1');
    expect(forked.meta.forkedFrom).toBe('base');
  });

  it('overrides the decision at the fork point and drops the rest', () => {
    const forked = fork(recording(), { at: 1, override: { value: 'B-PRIME' } });
    expect(forked.events).toHaveLength(2);
    const replayer = createReplayer(forked);
    expect(replayer.replay('llm', 'plan')).toBe('A');
    expect(replayer.replay('llm', 'plan')).toBe('B-PRIME');
  });

  it('prunes blobs to only those referenced by the kept prefix', () => {
    const forked = fork(recording(), { at: 1 });
    expect(Object.keys(forked.blobs)).toHaveLength(1);
  });

  it('rejects an out-of-range fork point', () => {
    expect(() => fork(recording(), { at: 99 })).toThrow(AgenticStashError);
    expect(() => fork(recording(), { at: -1 })).toThrow(/out of range/);
  });

  it('rejects an override with no event at the fork point', () => {
    expect(() => fork(recording(), { at: 3, override: { value: 'x' } })).toThrow(/no event/);
  });
});
