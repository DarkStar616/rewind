import { describe, expect, it } from 'vitest';
import { createStash, DROP, loadStash } from '../src/index.js';
import { sealRecording, verifyRecording } from '../src/seal/index.js';
import type { RedactContext } from '../src/types.js';

describe('redaction', () => {
  it('masks a value before it is stored, and replay serves the masked value', () => {
    const stash = createStash({
      id: 'r',
      redact: (value) =>
        typeof value === 'string' ? value.replace(/secret-\w+/g, '[REDACTED]') : value,
    });
    stash.value('llm', 'plan', 'token is secret-abc123 ok');
    const json = stash.save();
    expect(json).not.toContain('secret-abc123');
    expect(json).toContain('[REDACTED]');
    const replay = loadStash(json);
    expect(replay.value('llm', 'plan', 'x')).toBe('token is [REDACTED] ok');
  });

  it('drops a payload to metadata-only with the DROP sentinel', () => {
    const stash = createStash({ id: 'r', redact: () => DROP });
    stash.value('tool', 'search', { ssn: '111-22-3333' });
    const recording = stash.recording();
    expect(recording.events).toHaveLength(1);
    const stored = recording.blobs[recording.events[0]?.ref ?? ''];
    expect(stored).toEqual({ __agenticstashRedacted: true });
    expect(JSON.stringify(recording)).not.toContain('111-22-3333');
  });

  it('redacts inputs as well as values, with the right context', () => {
    const seen: RedactContext[] = [];
    const stash = createStash({
      id: 'r',
      redact: (value, ctx) => {
        seen.push(ctx);
        return value;
      },
    });
    stash.value('llm', 'plan', 'out', { input: 'in' });
    expect(seen).toContainEqual({ channel: 'llm', key: 'plan', kind: 'value' });
    expect(seen).toContainEqual({ channel: 'llm', key: 'plan', kind: 'input' });
  });

  it('keeps the seal valid over a redacted recording', async () => {
    const stash = createStash({ id: 'r', redact: () => '[REDACTED]' });
    stash.value('llm', 'plan', 'sensitive');
    const recording = stash.recording();
    const seal = await sealRecording(recording);
    expect((await verifyRecording(recording, seal)).valid).toBe(true);
  });

  it('stores verbatim when no redactor is set', () => {
    const stash = createStash({ id: 'r' });
    stash.value('llm', 'plan', 'plain-text');
    expect(stash.save()).toContain('plain-text');
  });
});
