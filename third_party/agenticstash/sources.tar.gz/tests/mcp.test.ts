import { describe, expect, it } from 'vitest';
import { createStash, loadStash } from '../src/index.js';
import { interceptMcpClient, recordMcpTool } from '../src/mcp/index.js';

describe('interceptMcpClient', () => {
  it('records tool results and replays them without touching the client', async () => {
    let calls = 0;
    const client = {
      callTool: (call: { name: string; arguments?: unknown }) => {
        calls += 1;
        return Promise.resolve({ tool: call.name, echo: call.arguments });
      },
    };
    const recordStash = createStash({ id: 'mcp' });
    const recorded = await interceptMcpClient(recordStash, client).callTool({
      name: 'search',
      arguments: { q: 'agents' },
    });
    expect(recorded).toEqual({ tool: 'search', echo: { q: 'agents' } });

    const replayStash = loadStash(recordStash.save());
    const replayed = await interceptMcpClient(replayStash, client).callTool({
      name: 'search',
      arguments: { q: 'agents' },
    });
    expect(replayed).toEqual(recorded);
    expect(calls).toBe(1);
  });
});

describe('recordMcpTool', () => {
  it('records and replays a single tool handler', async () => {
    const handler = (args: { city: string }) => Promise.resolve(`weather:${args.city}`);
    const recordStash = createStash({ id: 'mcp' });
    const tool = recordMcpTool(recordStash, 'weather', handler);
    expect(await tool({ city: 'lisbon' })).toBe('weather:lisbon');

    const replayStash = loadStash(recordStash.save());
    const replayTool = recordMcpTool(replayStash, 'weather', handler);
    expect(await replayTool({ city: 'lisbon' })).toBe('weather:lisbon');
  });
});
