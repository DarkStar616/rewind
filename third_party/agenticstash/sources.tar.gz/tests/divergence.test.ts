import { describe, expect, it } from 'vitest';
import { createStash, loadStash } from '../src/index.js';

/** Records a two-step run, then returns a fresh JSON recording to replay against. */
async function recordTwoSteps(): Promise<string> {
  const stash = createStash({ id: 'run' });
  await stash.intercept('llm', 'step1', () => Promise.resolve('A'), { input: 'in1' });
  await stash.intercept('llm', 'step2', () => Promise.resolve('B'), { input: 'in2' });
  return stash.save();
}

describe('divergence report (onDivergence: collect)', () => {
  it('reports a clean match when the replay follows the recording', async () => {
    const json = await recordTwoSteps();
    const replay = loadStash(json, { onDivergence: 'collect' });
    await replay.intercept('llm', 'step1', () => Promise.resolve('A'), { input: 'in1' });
    await replay.intercept('llm', 'step2', () => Promise.resolve('B'), { input: 'in2' });
    const report = replay.report();
    expect(report.matched).toBe(true);
    expect(report.divergences).toHaveLength(0);
    expect(report.consumed).toBe(2);
  });

  it('collects an input mismatch and keeps replaying instead of throwing', async () => {
    const json = await recordTwoSteps();
    const replay = loadStash(json, { onDivergence: 'collect' });
    const first = await replay.intercept('llm', 'step1', () => Promise.resolve('X'), {
      input: 'CHANGED',
    });
    expect(first).toBe('A'); // recorded value still served
    await replay.intercept('llm', 'step2', () => Promise.resolve('B'), { input: 'in2' });
    const report = replay.report();
    expect(report.matched).toBe(false);
    expect(report.firstDivergence?.kind).toBe('input-mismatch');
    expect(report.firstDivergence?.channel).toBe('llm');
  });

  it('reports a missing call when the replay skips a recorded step', async () => {
    const json = await recordTwoSteps();
    const replay = loadStash(json, { onDivergence: 'collect' });
    await replay.intercept('llm', 'step1', () => Promise.resolve('A'), { input: 'in1' });
    // step2 is never replayed
    const report = replay.report();
    expect(report.matched).toBe(false);
    expect(report.divergences.some((d) => d.kind === 'missing-call')).toBe(true);
  });

  it('reports an extra call when the replay adds a step', async () => {
    const json = await recordTwoSteps();
    const replay = loadStash(json, { onDivergence: 'collect' });
    await replay.intercept('llm', 'step1', () => Promise.resolve('A'), { input: 'in1' });
    await replay.intercept('llm', 'step2', () => Promise.resolve('B'), { input: 'in2' });
    const extra = await replay.intercept('llm', 'step3', () => Promise.resolve('LIVE'), {
      input: 'new',
    });
    expect(extra).toBe('LIVE'); // ran live since nothing was recorded
    const report = replay.report();
    expect(report.divergences.some((d) => d.kind === 'extra-call')).toBe(true);
  });

  it('still throws on the first divergence in the default mode', async () => {
    const json = await recordTwoSteps();
    const replay = loadStash(json);
    await expect(
      replay.intercept('llm', 'step1', () => Promise.resolve('X'), { input: 'CHANGED' }),
    ).rejects.toThrow(/ERR_DIVERGENCE|does not match/);
  });

  it('record-mode stash returns an empty report', () => {
    const stash = createStash({ id: 'r' });
    expect(stash.report().matched).toBe(true);
    expect(stash.divergences()).toEqual([]);
  });
});
